function Get-PlainText()
{
	[CmdletBinding()]
	param
	(
		[parameter(Mandatory = $true)]
		[System.Security.SecureString]$SecureString
	)
	begin { }
	process
	{
		$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString);
 		try
		{
			return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr);
		}
		finally
		{
			[Runtime.InteropServices.Marshal]::FreeBSTR($bstr);
		}
	}
	end { }
}
function Get-Encrypt()
{
	[CmdletBinding()]
	param
	(
		[parameter(Mandatory = $true)]
        [String]$PlainTextPassword,

        [parameter(Mandatory = $true)]
		[String]$KeyPath
	)
	begin { }
	process
	{
 		try
		{
            #Get Key
            $key = Get-Content $KeyPath

            #Convert To Secure Password
            $Password = $PlainTextPassword | ConvertTo-SecureString -AsPlainText -Force
			return $Password | ConvertFrom-SecureString -key $key
		}
		catch
		{
			"An Error Occured Processing The Password."
		}
	}
	end { }
}
function Get-Decrypt()
{
	[CmdletBinding()]
	param
	(
		[parameter(Mandatory = $true)]
        [String]$SecureStringAES,
        
        [parameter(Mandatory = $true)]
		[String]$KeyPath
	)
	begin { }
	process
	{
        #Create Default Key
        [Byte[]] $key = (1..16)


 		
            #Get Key
            $key = Get-Content $KeyPath
            
            #Convert To Secure Password
            $SecureString = $SecureStringAES | ConvertTo-SecureString -Key $key
            
            $Password = Get-PlainText -SecureString $SecureString
			return $Password
		
	}
	end { }
}

Export-ModuleMember -Function 'Get-Encrypt', 'Get-Decrypt' -Alias 'PwdMgr'